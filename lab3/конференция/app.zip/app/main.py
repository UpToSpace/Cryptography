from encryptor import *
from des import *

if __name__ == '__main__':
     key = "cryptkey"
     text = "aveffect"
     ciphered = encryptor.encrypt(text, key)
     plain = encryptor.decrypt(ciphered, key)
     print ("Plaintext: ", plain)
     print ("Ciphertext %r" % ciphered)
