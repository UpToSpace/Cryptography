from des import *

class encryptor:
    @staticmethod
    def encrypt(enter: str, key: str): # входная строка, ключ
        result = ""
        # encoded_text = des.bit_encode(enter)
        # print(encoded_text)
        # Обработка входной строки в блок длиной 64
        blocks = des.processing_encode_input(des, enter)
        for block in blocks:
            # Выполняем замену начального состояния для каждого блока
            irb_result = des.init_replace_block(des, block)
            # Выполняем 16 раундов циклического шифрования для каждого блока
            block_result = des.iteration(des, irb_result, key, is_decode=False)
            # Выполните замену окончательного состояния для каждой детали
            block_result = des.end_replace_block(des, block_result)
            # Возвращаем строку зашифрованного текста в шестнадцатеричной форме
            # result += str(hex(int(block_result.encode(), 2)))
            result += block_result
        return result

    def decrypt(cipher_text: str, key: str):
        result = []
        cipher_text = str(hex(int(cipher_text.encode(), 2)))
        blocks = des.processing_decode_input(cipher_text)
        for block in blocks:
            irb_result = des.init_replace_block(des, block)
            block_result = des.iteration(des, irb_result, key, is_decode=True)
            block_result = des.end_replace_block(des, block_result)
            for i in range(0, len(block_result), 8):
                result.append(block_result[i: i+8])
        return des.bit_decode(result)